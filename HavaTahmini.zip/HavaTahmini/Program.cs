﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace HavaTahmini
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            string[] cities = { "istanbul", "izmir", "ankara" };

            foreach (string city in cities)
            {
                try
                {
                    string weatherData = await GetWeatherDataAsync(city);
                    PrintWeatherData(city, weatherData);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Hata oluştu: {ex.Message}");
                }
            }
        }

        private static async Task<string> GetWeatherDataAsync(string city)
        {
            string apiKey = "YOUR_API_KEY";
            string apiUrl = $"https://goweather.herokuapp.com/weather/{city}?apikey={apiKey}";

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string weatherData = await response.Content.ReadAsStringAsync();
                    return weatherData;
                }
                else
                {
                    throw new Exception($"API'den veri alınamadı. HTTP durum kodu: {response.StatusCode}");
                }
            }
        }

        private static void PrintWeatherData(string city, string weatherData)
        {
            Console.WriteLine($"{city} Hava Durumu:");
            Console.WriteLine(weatherData);
            Console.WriteLine();
        }
    }
}
